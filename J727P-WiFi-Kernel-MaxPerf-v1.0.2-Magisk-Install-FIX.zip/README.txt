J727P Wi-Fi + Kernel Performance v1.0.2
TARGET: Samsung SM-J727P (j7popltespr), LineageOS 16 / Android 9, Magisk.

INSTALL
1. Back up your current working setup in recovery first.
2. Open Magisk > Modules > Install from storage, select the ZIP.
3. Reboot.
4. Inspect module.log in /data/adb/modules/j727p_wifi_maxperf.

WHAT IT DOES
- Requests Wi-Fi power saving OFF through iw (only if supported by the driver).
  Your Qualcomm BMPS config may already be OFF; this module DOES NOT rewrite
  any WLAN firmware file. Turning off power saving consumes more power.
- Requests larger TCP receive/send buffers on supported kernel sysctls.
- Uses the interactive CPU governor if available, plus kernel-supported
  frequency ranges. Does not touch voltages, kernel images, SELinux, LMK,
  thermal daemon, thermal driver, or radio TX power.
- Sets GPU min/max only when the standard devfreq nodes exist.
- Keeps the kernel's thermal controls enabled, and downgrades requested
  performance when the battery is already warm at application time.
- Uses a lightweight 2-minute Wi-Fi retry loop to handle Wi-Fi toggles.

NO GUARANTEE
Wi-Fi throughput is limited by AP, signal quality, interference, and hardware.
TCP tuning alone may not increase measured Wi-Fi rates. Some sysctls and
power-save commands may be unsupported, and will be logged as skipped.
The max supported frequencies in custom kernels can be less stable than stock.

EXISTING GODMODE MODULE
When j727p_lineage16_godmode or j727p_godmode is enabled, CPU/GPU tuning
is intentionally skipped to avoid both modules fighting. Wi-Fi/TCP remains
active. For this module to manage CPU/GPU instead, disable GodMode in Magisk
and REBOOT. Never run both CPU/GPU tuners simultaneously.

OPTIONAL CONTROLS (via rooted Termux)
  su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune status'
  su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune profile balanced'
  su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune profile performance'
  su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune profile turbo'
  su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune apply'
Turbo permits CPU up to 2208000 kHz IF the kernel advertises this frequency.
It is not recommended for hot batteries or extended sessions. Configurable
thermal gates deny turbo from 42 deg C and limit to balanced from 44 deg C.

To stop tuning: disable this module in Magisk and reboot. Sysfs/runtime
sysctl adjustments reset on reboot; no system/vendor partitions are modified.
Installer includes official Magisk v24.3 update-binary and #MAGISK marker.
Install via Magisk Modules > Install from storage.
Magisk recovery flashing has not been tested on this phone.
