J727P Wi-Fi and Kernel MaxPerf v1.0.4 for Magisk 24.3 / Android 9.
Installs no kernel or firmware. Keeps SELinux and thermal protection enabled.
Performance mode requests CPU 1.0368-2.016 GHz, GPU KGSL 216-650 MHz.
Wi-Fi power save OFF and TCP buffers 6 MiB if accepted by the driver.
Safety fix: NEVER tune gpubw or cpubw bandwidth-controller devfreq.
Previous 1.0.2 mistakenly wrote a bandwidth value 7104; REBOOT after upgrade.
Termux status: su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune status'
Disable module in Magisk then reboot to undo temporary runtime tuning.
Turbo is not recommended for hot batteries or prolonged sessions.

VERSION 1.0.4 WI-FI RECHECK CORRECTION
- On this SM-J727P, `iw dev wlan0 get power_save` can revert to ON within
  30 seconds even with gEnableBmps=0. The previous version waited 120 seconds
  between rechecks; this build checks every 20 seconds.
- The 20-second watchdog prints an explicit startup line in module.log and
  only issues an OFF request when the flag is reported ON.
- Change WIFI_CHECK_SECONDS in config.conf to an integer 10-120 if needed.
- Reboot after updating so the old 120-second watcher exits.
- The watchdog is a workaround; a driver/framework reset can still
  re-enable the flag between checks. Measure actual throughput before
  concluding it improves downloads.
