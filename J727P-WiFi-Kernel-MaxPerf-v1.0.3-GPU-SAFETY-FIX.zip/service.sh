#!/system/bin/sh
MODDIR=${0%/*}
# Magisk late_start service; never block Android boot.
(
  count=0
  while [ "$(getprop sys.boot_completed)" != 1 ] && [ "$count" -lt 100 ]; do
    sleep 2
    count=$((count + 1))
  done
  sleep 8
  /system/bin/sh "$MODDIR/bin/j7tune" boot >> "$MODDIR/module.log" 2>&1
) &
