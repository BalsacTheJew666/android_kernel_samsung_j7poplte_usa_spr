J727P Wi-Fi and Kernel MaxPerf v1.0.3 for Magisk 24.3 / Android 9.
Installs no kernel or firmware. Keeps SELinux and thermal protection enabled.
Performance mode requests CPU 1.0368-2.016 GHz, GPU KGSL 216-650 MHz.
Wi-Fi power save OFF and TCP buffers 6 MiB if accepted by the driver.
Safety fix: NEVER tune gpubw or cpubw bandwidth-controller devfreq.
Previous 1.0.2 mistakenly wrote a bandwidth value 7104; REBOOT after upgrade.
Termux status: su -c 'sh /data/adb/modules/j727p_wifi_maxperf/bin/j7tune status'
Disable module in Magisk then reboot to undo temporary runtime tuning.
Turbo is not recommended for hot batteries or prolonged sessions.
