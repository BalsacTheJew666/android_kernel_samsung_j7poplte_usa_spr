# Magisk installer: this file is SOURCED by Magisk. Do not use exit.
MODEL="$(getprop ro.product.model)"
DEVICE="$(getprop ro.product.device)"
API="$(getprop ro.build.version.sdk)"
case "$MODEL:$DEVICE" in
  SM-J727P:*|*:j7popltespr) ;;
  *) abort "This ZIP is only for the Samsung SM-J727P (j7popltespr). Detected: $MODEL / $DEVICE" ;;
esac
[ "$API" = 28 ] || abort "Designed for LineageOS 16 / Android 9 (SDK 28); detected SDK $API."
ui_print '- SM-J727P Android 9 detected'
ui_print '- Installs no kernel or firmware replacement'
ui_print '- Does not disable thermal management or SELinux'
if [ -d /data/adb/modules/j727p_lineage16_godmode ] && [ ! -e /data/adb/modules/j727p_lineage16_godmode/disable ]; then
 ui_print '- NOTE: Existing GodMode module detected'
 ui_print '- CPU/GPU tuning will be SKIPPED until GodMode is disabled'
fi
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/bin/j7tune" 0 0 0755
set_perm "$MODPATH/config.conf" 0 0 0644
